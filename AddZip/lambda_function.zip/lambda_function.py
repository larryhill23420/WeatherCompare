import json
import boto3
import uuid
import urllib.request
from datetime import datetime, timedelta, timezone
from decimal import Decimal

dynamodb = boto3.resource("dynamodb")
zip_table = dynamodb.Table("ZipCode")
reading_table = dynamodb.Table("Reading")
error_table = dynamodb.Table("Error")

def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

def log_error(zip_dt: str, description: str):
    error_table.put_item(Item={
        "UUID": str(uuid.uuid4()),
        "Zip_DateTime": zip_dt,
        "Description": description,
        "InsertedAt": now_iso()
    })

def http_get(url):
    req = urllib.request.Request(url, headers={"User-Agent": "WeatherCompare/1.0"})
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read().decode())

def do_backfill(zip_code, place_name, lat, lon, days):
    now = datetime.now(timezone.utc)
    start = (now - timedelta(days=days)).replace(hour=0, minute=0, second=0, microsecond=0)
    current = start
    inserted = 0

    while current <= now:
        dt_str = current.strftime("%Y-%m-%dT%H:00:00Z")
        zip_dt = f"{zip_code}_{dt_str}"
        date_str = current.strftime("%Y-%m-%d")

        weather_url = (
            "https://api.open-meteo.com/v1/forecast"
            f"?latitude={lat}&longitude={lon}"
            "&hourly=temperature_2m,relative_humidity_2m,cloud_cover,precipitation"
            "&temperature_unit=fahrenheit"
            f"&start_date={date_str}&end_date={date_str}"
            "&timezone=UTC"
        )

        try:
            w = http_get(weather_url)
            hourly = w.get("hourly", {})
            times = hourly.get("time", [])
            temps = hourly.get("temperature_2m", [])
            hums = hourly.get("relative_humidity_2m", [])
            clouds = hourly.get("cloud_cover", [])
            precips = hourly.get("precipitation", [])

            target = dt_str[:13]
            idx = next((i for i, t in enumerate(times) if t.startswith(target)), None)

            if idx is None or not temps:
                raise ValueError(f"No data for hour {dt_str}")

            reading_table.put_item(Item={
                "Zip_DateTime": zip_dt,
                "DateTime": dt_str,
                "ZipCode": zip_code,
                "PlaceName": place_name,
                "Temperature": Decimal(str(round(temps[idx]))),
                "Precipitation": Decimal(str(precips[idx] if precips else 0)),
                "Humidity": Decimal(str(round(hums[idx]))) if hums else Decimal("0"),
                "CloudCover": Decimal(str(round(clouds[idx]))) if clouds else Decimal("0"),
                "InsertedAt": now_iso()
            })
            inserted += 1
        except Exception as e:
            log_error(zip_dt, f"Weather API failed: {weather_url} | {str(e)}")

        current += timedelta(hours=1)
    return inserted

def lambda_handler(event, context):
    params = event.get("queryStringParameters") or {}
    zip_code = params.get("zip")
    days = int(params.get("days", "7"))
    days = max(1, min(days, 7))

    if not zip_code:
        return {
            "statusCode": 400,
            "headers": {"Access-Control-Allow-Origin": "*"},
            "body": json.dumps({"success": False, "error": "zip is required"})
        }

    # Lookup
    zip_url = f"https://api.zippopotam.us/us/{zip_code}"
    try:
        z = http_get(zip_url)
        place = z["places"][0]
        place_name = f"{place['place name']}, {place['state abbreviation']}"
        lat = place["latitude"]
        lon = place["longitude"]
    except Exception as e:
        log_error(f"{zip_code}_ZIP_LOOKUP", f"Zippopotam failed: {zip_url} | {str(e)}")
        return {
            "statusCode": 400,
            "headers": {"Access-Control-Allow-Origin": "*"},
            "body": json.dumps({"success": False, "error": f"Zip lookup failed: {str(e)}"})
        }

    # EXISTS check
    existing = zip_table.get_item(Key={"ZipCode": zip_code, "PlaceName": place_name})
    if "Item" in existing:
        return {
            "statusCode": 400,
            "headers": {"Access-Control-Allow-Origin": "*"},
            "body": json.dumps({"success": False, "error": f"Zip {zip_code} already exists"})
        }

    # Insert ZipCode immediately
    zip_table.put_item(Item={
        "ZipCode": zip_code,
        "PlaceName": place_name,
        "Latitude": lat,
        "Longitude": lon,
        "InsertedAt": now_iso()
    })

    # Start backfill (still synchronous for now, but we return fast if we want)
    # For true async you'd use a second invocation; this version still does the work
    # but we can raise timeout and accept it.
    inserted = do_backfill(zip_code, place_name, lat, lon, days)

    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        },
        "body": json.dumps({
            "success": True,
            "place_name": place_name,
            "readings_inserted": inserted
        })
    }